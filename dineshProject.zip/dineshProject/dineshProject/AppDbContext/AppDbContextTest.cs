﻿using dineshProject.Entity;
using Microsoft.EntityFrameworkCore;

namespace dineshProject.AppDbContext
{
    public class AppDbContextTest : DbContext
    {
        public AppDbContextTest() { }
        public AppDbContextTest(DbContextOptions<AppDbContextTest> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Employee> Employees { get; set; }


        //Scaffold-DbContext "Server=192.168.0.31;Database=testProject;User Id=rajesh;Password=Rajesh22#;TrustServerCertificate=True;" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Models -Context AppDbContext -f

    }
}
