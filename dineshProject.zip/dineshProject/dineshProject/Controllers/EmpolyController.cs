﻿using dineshProject.Dto.DtoInput;
using dineshProject.Dto.DtoOutput;
using dineshProject.Models;
using dineshProject.Service.Interface;
using Microsoft.AspNetCore.Mvc;

namespace dineshProject.Controllers
{
    public class EmpolyController : Controller
    {
        public IUserService _userService;
        public IEmpolyService _empolyService;
        public EmpolyController(IUserService userService, IEmpolyService empolyService)
        {
            _userService = userService;
            _empolyService = empolyService;
        }

   

    }
}
