﻿using dineshProject.Dto.DtoInput;
using dineshProject.Dto.DtoOutput;
using dineshProject.Models;
using dineshProject.Service.Interface;
using Microsoft.AspNetCore.Mvc;

namespace dineshProject.Controllers
{
    public class UserController : Controller
    {
        public IUserService _userService;
        public UserController(IUserService userService)
        {
            _userService = userService;
        }
        public async Task<IActionResult> addUpdateForm(int id)
        {
            if(!ModelState.IsValid)
            {
                return View("~/Views/User/addUpdateForm.cshtml");
            }
            else
            {
                if(id !=0)
                {
                    var rslt = await _userService.getUserById(id);
                    ViewData["userData"] = rslt.Data;
                    return View("~/Views/User/addUpdateForm.cshtml");
                }
                else
                {
                    return View("~/Views/User/addUpdateForm.cshtml");
                }
            }
            return View("addUpdateForm");
        }

        public async Task<IActionResult> addUpdateUser([FromForm] UserInput model)
        {
            try
            {
                //if (!ModelState.IsValid)
                //{
                //    ViewData["userData"] = model;
                //    return View("~/Views/User/addUpdateForm.cshtml");
                //}
                var rslt = new ApiResponseModel<UserOutput>();
                if (model != null)
                {
                   

                    rslt = await _userService.addUpdateUser(model);
                    if (rslt.succeed)
                    {
                        TempData["Success"] = rslt.Message;
                        return Redirect("~/User/userlist");
                    }
                    else
                    {
                        TempData["Error"] = rslt.Message;
                        return RedirectToAction("addUpdateForm", "User");
                    }
                }
                else
                {
                    TempData["Error"] = rslt.Message;
                    return RedirectToAction("addUpdateForm", "User");
                }
            }
            catch (Exception ex)
            {
                TempData["Error"] = "Something went wrong: " + ex.Message;
                return RedirectToAction("addUpdateForm", "User");
            }
        }


        public async Task<IActionResult>userlist()
        {
            try
            {
                var rslt = await _userService.getUser();
                ViewData["userData"] = rslt.Data;
                return View("~/Views/User/userlist.cshtml");
            }
            catch(Exception ex)
            {
                throw new Exception (ex.Message, ex);
            }
        }

        public async Task<IActionResult>deleteUser(int id)
        {
           
                var rslt = await _userService.delteUser(id);
                TempData[rslt.succeed ? "success" : "error"] = rslt.Message;
                return Redirect(Request.Headers["Referer"].ToString());
           
        }



    }
}
