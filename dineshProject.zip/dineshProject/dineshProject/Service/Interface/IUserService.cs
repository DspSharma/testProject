﻿using dineshProject.Dto.DtoInput;
using dineshProject.Dto.DtoOutput;
using dineshProject.Models;

namespace dineshProject.Service.Interface
{
    public interface IUserService
    {
        Task<ApiResponseModel<UserOutput>> addUpdateUser(UserInput model);
        Task<ApiResponseModel<List<UserOutput>>> getUser();
        Task<ApiResponseModel<bool>> delteUser(int id);
        Task<ApiResponseModel<UserOutput>> getUserById(int id);
    }
}
