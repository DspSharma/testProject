﻿using dineshProject.Dto.DtoInput;
using dineshProject.Dto.DtoOutput;
using dineshProject.Models;

namespace dineshProject.Service.Interface
{
    public interface IEmpolyService
    {
        Task<ApiResponseModel<EmployeeOutput>> addUpdateEmployee(EmployeeInput model);
        Task<ApiResponseModel<List<EmployeeOutput>>> getEmployeeOutput(int userId);
    }
}
