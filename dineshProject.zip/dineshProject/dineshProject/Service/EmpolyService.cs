﻿using dineshProject.AppDbContext;
using dineshProject.Dto.DtoInput;
using dineshProject.Dto.DtoOutput;
using dineshProject.Entity;
using dineshProject.Models;
using dineshProject.Service.Interface;
using Microsoft.EntityFrameworkCore;

namespace dineshProject.Service
{
    public class EmpolyService : IEmpolyService
    {
        public AppDbContextTest _appDbContext;
        private IWebHostEnvironment _environment;
        public EmpolyService(AppDbContextTest appDbContext, IWebHostEnvironment environment)
        {
            _appDbContext = appDbContext;
            _environment = environment;
        }
       
        public static string uploadFileToLocal(IFormFile file, string dirpath)
        {
            string uniqueFileName = Guid.NewGuid().ToString() + "_" + file.FileName;
            string filepath = Path.Combine(dirpath, uniqueFileName);
            var fileStream = new FileStream(filepath, FileMode.Create);
            file.CopyTo(fileStream);
            fileStream.Dispose();
            return uniqueFileName;
            //return filepath;
        }
        public async Task<ApiResponseModel<EmployeeOutput>> addUpdateEmployee(EmployeeInput model)
        {
            try
            {
                if (model == null)
                {
                    return new ApiResponseModel<EmployeeOutput>
                    {
                        succeed = false,
                        Message = "Required fields are missing."
                    };
                }
                string imageUrl = "";
                if (model.fileImage != null && model.fileImage.Length > 0)
                {
                    string dirpath = Path.Combine(_environment.WebRootPath, "images", "Image");
                    string filePath = uploadFileToLocal(model.fileImage, dirpath);
                    imageUrl = filePath;

                }
                var employee = model.Id == 0 ? new Employee() : await _appDbContext.Employees.FindAsync(model.Id);
                if (employee == null)
                {
                    return new ApiResponseModel<EmployeeOutput> { succeed = false, Message = "Employee not found." };
                }
                employee.salary = model.salary;
                employee.age = model.age;
                employee.EmployeeType = model.EmployeeType;
                if (model.fileImage != null)
                {
                    employee.Image = imageUrl;

                }
                employee.UpdatedAt = DateTime.UtcNow;
                if (model.Id == 0)
                {
                    employee.Image = imageUrl;
                    employee.CreatedAt = DateTime.UtcNow;
                    await _appDbContext.Employees.AddAsync(employee);
                }
                await _appDbContext.SaveChangesAsync();
                return new ApiResponseModel<EmployeeOutput>
                {
                    succeed = true,
                    Message = model.Id == 0 ? "Employee added." : "Employee updated.",
                };
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<ApiResponseModel<List<EmployeeOutput>>> getEmployeeOutput(int userId)
        {
            try
            {
                // onlay userid sh data start ==========================================================================================

                var employees = await _appDbContext.Employees.Where(e => e.UserId == userId)
                                .Select(e => new EmployeeOutput
                                {
                                    salary = e.salary,
                                    age = e.age,
                                    UserId = e.UserId,
                                    Image = e.Image,
                                    EmployeeType = e.EmployeeType,
                                    CreatedAt = e.CreatedAt,
                                    UpdatedAt = e.UpdatedAt
                                }).ToListAsync();

                // onlay userid sh data end ============================================================================================

                // join query start =============================================================================================================

                //var employees = await (from emp in _appDbContext.Employees
                //                       join user in _appDbContext.Users on emp.UserId equals user.Id
                //                       where emp.UserId == userId
                //                       select new EmployeeOutput
                //                       {
                //                           Id = emp.Id,
                //                           salary = emp.salary,
                //                           age = emp.age,
                //                           UserId = user.Id,
                //                           UserName = user.FirstName + " " + user.LastName,
                //                           Image = emp.Image,
                //                           EmployeeType = emp.EmployeeType,
                //                           CreatedAt = emp.CreatedAt,
                //                           UpdatedAt = emp.UpdatedAt,
                //                       }).ToListAsync();

                // join query end   ==============================================================================================================
                if (employees == null || !employees.Any())
                {
                    return new ApiResponseModel<List<EmployeeOutput>>
                    {
                        succeed = false,
                        Message = "No employees found for the given UserId."
                    };
                }
                return new ApiResponseModel<List<EmployeeOutput>>
                {
                    succeed = true,
                    Data = employees,
                    Message = "Employees fetched successfully."
                };
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }






    }
}
