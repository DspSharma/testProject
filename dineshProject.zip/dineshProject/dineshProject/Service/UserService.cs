﻿using AutoMapper;
using dineshProject.AppDbContext;
using dineshProject.Dto.DtoInput;
using dineshProject.Dto.DtoOutput;
using dineshProject.Entity;
using dineshProject.Models;
using dineshProject.Service.Interface;
using Microsoft.EntityFrameworkCore;

namespace dineshProject.Service
{
    public class UserService : IUserService
    {
        public AppDbContextTest _appDbContextTest;
       // public IMapper _mapper;
        public UserService(AppDbContextTest appDbContextTest)
        {
            _appDbContextTest = appDbContextTest;
           // _mapper = mapper;
        }
        public async Task<ApiResponseModel<UserOutput>>addUpdateUser(UserInput model)
        {
            try
            {
                if (model == null)
                {
                    return new ApiResponseModel<UserOutput>
                    {
                        succeed = false,
                        Message = "Required fields are missing."
                    };
                }

                // ✅ Combined Duplicate Check
                var isDuplicate = await _appDbContextTest.Users.AnyAsync(u =>(u.Email == model.Email || u.Phone == model.Phone) && u.Id != model.Id);
                if (isDuplicate)
                {
                    return new ApiResponseModel<UserOutput>
                    {
                        succeed = false,
                        Message = "A user with this email or phone number already exists."
                    };
                }


                var user = model.Id == 0 ? new User() : await _appDbContextTest.Users.FindAsync(model.Id);
                if (user == null)
                {
                    return new ApiResponseModel<UserOutput> { succeed = false, Message = "User not found." };
                }
                user.FirstName = model.FirstName;
                user.LastName = model.LastName;
                user.Email = model.Email;
                user.Password = model.Password;
                user.Phone = model.Phone;
                user.UserType = model.UserType;
                user.UpdatedAt = DateTime.UtcNow;
                if (model.Id == 0)
                {
                    user.CreatedAt = DateTime.UtcNow;
                    await _appDbContextTest.Users.AddAsync(user);
                }
                await _appDbContextTest.SaveChangesAsync();
                return new ApiResponseModel<UserOutput>
                {
                    succeed = true,
                    Message = model.Id == 0 ? "User added." : "User updated.",
                };
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
           
        }

        public async Task<ApiResponseModel<List<UserOutput>>>getUser()
        {
            try
            {
                //List<User> users = await _appDbContextTest.Users.ToListAsync();
                //var rslt = _mapper.Map<List<UserOutput>>(users);


                var users = await _appDbContextTest.Users.ToListAsync();
                var rslt = users.Select(u => new UserOutput
                {
                    Id = u.Id,
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Email = u.Email,
                    Phone = u.Phone
                }).ToList();

                return new ApiResponseModel<List<UserOutput>>
                {
                    succeed = true,
                    Message = "Success",
                    Data = rslt
                };
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<ApiResponseModel<UserOutput>>getUserById(int id)
        {
            try
            {
                var user = await _appDbContextTest.Users.FindAsync(id);
                if (user == null)
                {
                    return new ApiResponseModel<UserOutput>
                    {
                        succeed = false,
                        Message = "User not found"
                    };
                }
               // UserOutput rslt = _mapper.Map<UserOutput>(user);
                return new ApiResponseModel<UserOutput>
                {
                    succeed = true,
                    Message = "success",
                    Data = new UserOutput
                    {
                        Id = user.Id,
                        FirstName = user.FirstName,
                        LastName = user.LastName,
                        Email = user.Email,
                        Phone = user.Phone
                    }
                    //Data = rslt
                };
            }
            catch (Exception ex)
            {
                throw new Exception (ex.Message, ex);
            }
        }

        public async Task<ApiResponseModel<bool>>delteUser(int id)
        {
            try
            {
                var user = await _appDbContextTest.Users.FindAsync(id);
                if (user == null)
                {
                    return new ApiResponseModel<bool>
                    {
                        succeed = false,
                        Message = "User not found"
                    };
                }

                _appDbContextTest.Users.Remove(user);
                await _appDbContextTest.SaveChangesAsync();

                return new ApiResponseModel<bool>
                {
                    succeed = true,
                    Message = "User deleted successfully"
                };
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }


        
    }
}
