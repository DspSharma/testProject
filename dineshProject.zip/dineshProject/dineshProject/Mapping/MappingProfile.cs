﻿using AutoMapper;
using dineshProject.Dto.DtoInput;
using dineshProject.Dto.DtoOutput;
using dineshProject.Entity;

namespace dineshProject.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<UserInput, User>();
            CreateMap<UserOutput, User>();
            CreateMap<User,UserOutput>();
        }
    }
}
