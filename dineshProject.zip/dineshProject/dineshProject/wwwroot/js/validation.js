﻿function userAddUpdate() {
    let firstName = $('#firstName').val().trim();
    let lastName = $('#lastName').val().trim();
    let email = $('#email').val().trim();
    let password = $('#Password').val().trim();
    let phone = $('#Phone').val().trim();
    let userType = $('#inputState').val();

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const nameRegex = /^[A-Za-z]+$/;
    const phoneRegex = /^[0-9]{10}$/;

    $(".error").remove(); // remove old errors if needed

    // First Name
    if (firstName === '') {
        toastr.error("First Name is required");
        return false;
    } else if (!nameRegex.test(firstName)) {
        toastr.error("First Name must contain only letters");
        return false;
    } else if (firstName.length < 2 || firstName.length > 50) {
        toastr.error("First Name must be 2–50 characters");
        return false;
    }

    // Last Name
    if (lastName === '') {
        toastr.error("Last Name is required");
        return false;
    } else if (!nameRegex.test(lastName)) {
        toastr.error("Last Name must contain only letters");
        return false;
    } else if (lastName.length < 2 || lastName.length > 50) {
        toastr.error("Last Name must be 2–50 characters");
        return false;
    }

    // Email
    if (email === '') {
        toastr.error("Email is required");
        return false;
    } else if (!emailRegex.test(email)) {
        toastr.error("Invalid email format");
        return false;
    } else if (email.length < 10 || email.length > 100) {
        toastr.error("Email must be between 10 and 100 characters");
        return false;
    }

    // Password
    if (password === '') {
        toastr.error("Password is required");
        return false;
    } else if (password.length < 6 || password.length > 15) {
        toastr.error("Password must be 6–15 characters");
        return false;
    }

    // Phone
    if (phone === '') {
        toastr.error("Phone is required");
        return false;
    } else if (!phoneRegex.test(phone)) {
        toastr.error("Phone must be exactly 10 digits");
        return false;
    }

    // UserType
    if (userType === '' || userType === 'Choose...') {
        toastr.error("Please select User Type");
        return false;
    }

    // ✅ All validations passed
    return true;
}
