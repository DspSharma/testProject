﻿using Microsoft.Build.Framework;
using System.ComponentModel.DataAnnotations;
using RequiredAttribute = System.ComponentModel.DataAnnotations.RequiredAttribute;


namespace dineshProject.Dto.DtoInput
{
    public class UserInput : BaseInput
    {
        [Required(ErrorMessage = "First Name is required")]
        [RegularExpression("^[A-Za-z][A-Za-z ]*$", ErrorMessage = "First Name must start with a letter and contain only letters or spaces")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Last Name is required")]
        public string LastName { get; set; }
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email format")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Password is required")]
        [StringLength(15, MinimumLength = 6, ErrorMessage = "Password must be between 6 and 15 characters")]
        public string Password { get; set; }
        [Required(ErrorMessage = "Phone number is required")]
        [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "Phone number must be exactly 10 digits")]
        public string Phone { get; set; }
        public int UserType { get; set; }


        //[Required(ErrorMessage = "Age is required")]
        //[RegularExpression("^[0-9]+$", ErrorMessage = "Age must be a valid number")]
    }
}
