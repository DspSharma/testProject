﻿using dineshProject.Entity;

namespace dineshProject.Dto.DtoInput
{
    public class EmployeeInput : BaseInput
    {
        public string salary { get; set; }
        public int age { get; set; }
        public int UserId { get; set; }
        public string Image { get; set; }
        public IFormFile fileImage { get; set; }
        public string EmployeeType { get; set; }
    }
}
