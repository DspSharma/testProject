﻿namespace dineshProject.Dto.DtoOutput
{
    public class EmployeeOutput : BaseOutput
    {
        public string salary { get; set; }
        public int age { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string Image { get; set; }
        public string EmployeeType { get; set; }
    }
}
