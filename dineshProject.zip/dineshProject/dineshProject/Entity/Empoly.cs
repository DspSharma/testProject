﻿namespace dineshProject.Entity
{
    public class Employee : BaseEntity
    {
        public string salary {  get; set; }
        public int age {  get; set; }
        public int UserId { get; set; }
        public User User { get; set; }
        public string Image {  get; set; }
        public string EmployeeType { get; set; }
    }
}
